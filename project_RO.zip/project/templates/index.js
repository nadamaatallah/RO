$(document).ready(function() {
    $('#route-form').submit(function(event) {
        event.preventDefault();

        var source = $('#source').val();
        var target = $('#target').val();
        var algorithm = $('#algorithm').val();

        $.post("/calculate_shortest_path", { source: source, target: target, algorithm: algorithm }, function(response) {
            $('#path').html('Chemin le plus court: ' + JSON.stringify(response));

            // Visualize path on the map (optional, assuming you have coordinates)
            // Clear previous map content
            $('#map-container').html('');

            // Use Leaflet.js to display the path on the map
            var map = L.map('map-container').setView([52.5, -1.5], 6); // Center map on England
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            // Assuming the response contains a list of nodes with their coordinates
            var pathCoordinates = response.map(function(node) {
                // Replace this with the actual way to get latitude and longitude of the node
                return [node.lat, node.lon];
            });

            var polyline = L.polyline(pathCoordinates, {color: 'blue'}).addTo(map);

            // Zoom the map to the polyline
            map.fitBounds(polyline.getBounds());

            // Show the result section
            $('#result').show();
        });
    });
});