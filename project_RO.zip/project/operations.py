import networkx as nx

def dijkstra_shortest_path(graph, source, target):
    return nx.dijkstra_path(graph, source, target)

def bellman_ford_shortest_path(graph, source, target):
    return nx.bellman_ford_path(graph, source, target)

def depth_first_search(graph, source, target):
    return list(nx.dfs_edges(graph, source))[0]

def breadth_first_search(graph, source, target):
    return list(nx.bfs_edges(graph, source))[0]
