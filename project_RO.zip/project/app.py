from flask import Flask, render_template, request, jsonify
import networkx as nx
import os

app = Flask(__name__)

# Load graphs from saved files
graphs = {}
output_dir = "city_graphs"
for filename in os.listdir(output_dir):
    if filename.endswith(".graphml"):
        city_name = filename.replace("_graph.graphml", "")
        graph_path = os.path.join(output_dir, filename)
        graphs[city_name] = nx.read_graphml(graph_path)

# Define the helper functions for calculating shortest paths
def dijkstra_shortest_path(graph, source, target):
    return nx.shortest_path(graph, source=source, target=target, weight='weight')

def bellman_ford_shortest_path(graph, source, target):
    return nx.bellman_ford_path(graph, source=source, target=target, weight='weight')

def depth_first_search(graph, source, target):
    return list(nx.dfs_edges(graph, source=source, depth_limit=10))

def breadth_first_search(graph, source, target):
    return list(nx.bfs_edges(graph, source=source, depth_limit=10))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate_shortest_path', methods=['POST'])
def calculate_shortest_path():
    # Receive data from the request
    source = request.form['source']
    target = request.form['target']
    algorithm = request.form['algorithm']

    # Check if the algorithm is supported
    if algorithm not in ["dijkstra", "bellman_ford", "dfs", "bfs"]:
        return "Algorithm not supported", 400

    # Check if the selected city exists in the graphs dictionary
    city = "London"  # Default city (you can modify this based on your requirements)
    if city not in graphs:
        return "City not found in the graph data", 400

    # Retrieve the graph associated with the selected city
    graph = graphs[city]

    # Check if the source and target nodes exist in the graph
    if source not in graph.nodes or target not in graph.nodes:
        return "Source or target node not found in the graph", 400

    # Calculate the shortest path based on the selected algorithm
    if algorithm == "dijkstra":
        path = dijkstra_shortest_path(graph, source, target)
    elif algorithm == "bellman_ford":
        path = bellman_ford_shortest_path(graph, source, target)
    elif algorithm == "dfs":
        path = depth_first_search(graph, source, target)
    elif algorithm == "bfs":
        path = breadth_first_search(graph, source, target)

    # Prepare the response
    response = {"path": path, "distance": calculate_distance(graph, path)}

    # Return the response
    return jsonify(response)

def calculate_distance(graph, path):
    distance = 0
    for i in range(len(path) - 1):
        distance += graph[path[i]][path[i+1]]['weight']
    return distance

if __name__ == '__main__':
    app.run(debug=True)